//chapter 1 start
/*
//1
alert("welcome");
//
//2
alert("Error! Please enter a valid password.");
//
//3
alert("welcome to JS Land..."+'\n'+"Happy Coding");
//
//4
alert("Welcome to JS Land...");
//
//5
alert("Hello.. I can run JS through my web browser's console");
*/
//end

//chapter2 start
/*
//1
var username;
//
//2
var myName = "farisKhan";
//
//3
var message;
message = "Hello World";
alert(message);
//
//4
var studentName,age,course;
studentName = "Faris Khan";
age = "26 years old";
course = "Mobile and web development";
alert("Name : "+studentName);
alert("Age : "+age);
alert("Course : "+course);
//
//5
var pizza = "PIZZA";
alert(pizza+"\n"+pizza[0]+pizza[1]+pizza[2]+pizza[3]+"\n"+pizza[0]+pizza[1]+pizza[2]+"\n"+pizza[0]+pizza[1]+"\n"+pizza[0]);
//
//6
var email = "My email address is ";
alert(email+"fariskhan023@gmail.com");
//
//7
var book = "A smarter \n way to learn JavaScript";
alert("I am trying to learn from the book "+book);
//
//8
var text = "Yah! I can write HTML content through JavaScript";
document.write(text);
//
//9
var textWithSymbols = "“▬▬▬▬▬▬▬▬▬ஜ۩۞۩ஜ▬▬▬▬▬▬▬▬▬”";
alert(textWithSymbols);
*/
//end

//chapter 3 start
/*
//1
var age = 23;
alert("I am "+age+" years old");
//
//2
var counter = 0;
counter++;
alert("you have visited this site "+counter+" times");
counter++;
alert("you have visited this site "+counter+" times");
counter++;
alert("you have visited this site "+counter+" times");
//
//3
var birthYear = 1995;
document.write("My birth year is "+birthYear+"<br>");
document.write("Data type of my declared variable is "+typeof(birthYear)+"<br>");
//
//4
var customerName = "John Doe";
var quantity = 5;
var product = "T-shirt(s)";
var order = quantity+product;
document.write(customerName+" ordered "+order+" on XYZ Clothing store");
//
*/
//end
//chapter 4 start
/*
//1
var a,b,c;
//
//2
//variable with legal names
var game;
var sports;
var movie;
var anime;
var student;

//variable with illegal names
//var $game;
//var #sports;
//var 2movie;
//var !anime;
//var 1student;
//
//3
document.write("<h1>Rules for naming  JS variables</h1>");
document.write("Variable names can only contain , numbers, $ and _ . For example : $my_1stVariable<br>");
document.write("Variable must begin with a letter, $ or _ . For example : $name, _name or name<br>");
document.write("Variable names are case sensitive<br>");
document.write("Variable names should not be JS keywords");
//
*/
//end

//chapter5 start
//1
var a = 3;
var b = 5;
var c = a + b;
document.write("Sum of "+a+" and "+b+" is "+ c +"<br>");
//
//2
c = a - b;
document.write("Subtraction of "+a+" and "+b+" is "+ c+"<br>");

c = a * b;
document.write("Multiplication of "+a+" and "+b+" is "+ c +"<br>");

c = a / b;
document.write("Division of "+a+" and "+b+" is "+ c +"<br>");

c = a % b;
document.write("modulus of "+a+" and "+b+" is "+ c +"<br>");

//
//3
var vr;
document.write("Value after variable declaration is : ??<br>");
vr = 5;
document.write("Initial value : "+vr+"<br>");
vr++;
document.write("Value after increment is : "+vr+"<br>");
vr = vr + 7;
document.write("Value after addition is : "+vr+"<br>");
vr--;
document.write("Value after decrement is : "+vr+"<br>");
document.write("The remainder is : "+vr/3+"<br>");
//
//4
var ticketPrice = 600;
var qty = 5;
var totalPrice = ticketPrice * qty;
document.write("Total cost to buy "+qty+" "+"tickets"+" "+"to a movie is "+totalPrice+"PKR<br>");
//
//5
var tNumber = 4;
var counter = 1;
document.write("Table of 4<br>");
document.write(tNumber+" x "+ counter +' = '+ tNumber*counter+"<br>");
counter++;
document.write(tNumber+" x "+ counter +' = '+ tNumber*counter+"<br>");
counter++;
document.write(tNumber+" x "+ counter +' = '+ tNumber*counter+"<br>");
counter++;
document.write(tNumber+" x "+ counter +' = '+ tNumber*counter+"<br>");
counter++;
document.write(tNumber+" x "+ counter +' = '+ tNumber*counter+"<br>");
counter++;
document.write(tNumber+" x "+ counter +' = '+ tNumber*counter+"<br>");
counter++;
document.write(tNumber+" x "+ counter +' = '+ tNumber*counter+"<br>");
counter++;
document.write(tNumber+" x "+ counter +' = '+ tNumber*counter+"<br>");
counter++;
document.write(tNumber+" x "+ counter +' = '+ tNumber*counter+"<br>");
counter++;
document.write(tNumber+" x "+ counter +' = '+ tNumber*counter+"<br>");
//
//6
var celcius = 25;
var celToFahren = celcius * (9/5) + 32;
document.write(celcius+"<sup>0</sup>"+'C'+" is "+celToFahren+"<sup>0</sup>"+'F<br>');
var fahren = 70;
var fahrenToCel = (fahren - 32) * 5/9 ;
document.write(fahren+"<sup>0</sup>F"+" is "+fahrenToCel+"<sup>0</sup>C<br>");
//
//7
var priceItem1 = 650;
var priceItem2 = 100;
var orderedQuantityItem1 = 3;
var orderedQuantityItem2 = 7;
 var shippingCharges = 100;
 var totalItem1 = priceItem1 * orderedQuantityItem1;
 var totalItem2 = priceItem2 * orderedQuantityItem2;
 var total = totalItem1 + totalItem2 + shippingCharges;
 
 document.write("Shopping Cart");
 document.write("Price of item 1 is "+priceItem1+"<br>");
document.write("Quantity of item 1 is "+orderedQuantityItem1+"<br>");
document.write("Price of item 2 is "+priceItem2+"<br>");
document.write("Quantity of item 2 is "+orderedQuantityItem2+"<br>");
document.write("Shipping Charges "+shippingCharges+"<br>");
document.write("Total cost of your order is "+total);
//
//8
var totalMarks = 980;
var obtained = 804;
var percentage = obtained*100/totalMarks;
document.write("Total marks : "+totalMarks+"<br>");
document.write("Marks obtained : "+obtained+"<br>");
document.write("Percentage : "+percentage+"%"+"<br>");

//
//9
var usDollars = 10;
var saudiRiyals = 25;
var dollarToRupee = 104.80;
var  riyalToRupee = 28;
var totalToPkr = (usDollars * dollarToRupee) + (saudiRiyals * riyalToRupee);
document.write("<h1>Currency in PKR</h1>");
document.write("Total Currency in PKR : "+totalToPkr+"<br>");
//
//10
var number = 3;
document.write((number + 5) * 10 / 2+"<br>");
//
//11
var currentYear = 2021;
var myBirthYear = 1995;
var myAge = currentYear - myBirthYear;
document.write("<h1>Age Calculator</h1>");
document.write("Current Year : "+currentYear+"<br>");
document.write("Birth Year : "+myBirthYear+"<br>");
document.write("Your Age is : "+myAge+"<br>");
//
//12
//sorry tried but could'nt do it
//
//13
var favouriteSnack = "choclate chip";
var currentAge =  15;
var estimatedMaximum = 65;
var snacksPerDay = 3;
document.write("FAvourite Snack : "+favouriteSnack+"<br>");
document.write("Current age : "+currentAge+"<br>");
document.write("Estimated Maximum Age : "+ estimatedMaximum+"<br>");
document.write("You will need "+(estimatedMaximum-currentAge)*snacksPerDay+" chocolate chip to last you until the ripe old age is "+estimatedMaximum+"<br>");
//
//end
//chapter 6-9 start
//1
var a = 10;
document.write("The value of a is :"+a+"<br>");
++a;
document.write("The value of ++a is : "+a+"<br>");
document.write("Now the value of a is : "+a+"<br>");
document.write("The value of a++ is : "+a+"<br>");
a++;
document.write("Now the value of a is : "+a+"<br>");
a--;
document.write("The value of a-- is : "+a+"<br>");
document.write("Now the value of a is : "+a+"<br>");
document.write("The value of a-- is : "+a+"<br>");
a--;
document.write("Now the value of a is : "+a+"<br>");
//
//2
var a = 2,b = 1; 
var result = --a - --b + ++b +b--;
document.write("a is "+a+"<br>");
document.write("b is "+b+"<br>");
document.write("result is "+result+"<br>");
/*
explaination
--a; a is equal to 1 beacuse of pre decrement
--b; b is equal to 0 beacuse of pre decrement
--a - --b is means 1 - 0 = 1
++b; b is now equal to 1 beacuse of pre decrement
--a - --b + ++b + b--; means 1 - 0 + 1 + 1-- is equal to 3 and now b is equal to 0
result = --a - --b + ++b + b--; result is equal to 3
that's it, thank you
*/
//
//3
var name = prompt ("what's your name?");
if(name)
{
document.write("<h1>welcome "+name+"</h1>"+"<br>");
}
else
{
document.write("<h1>welcome user</h1>");
}
//
//4 or 5
var number = prompt("type a number");
var counter = 1;
if(number)
{
number = parseInt(number);
document.write(number+" x "+counter+" = "+number*counter+"<br>");
counter++;
document.write(number+" x "+counter+" = "+number*counter+"<br>");
counter++;
document.write(number+" x "+counter+" = "+number*counter+"<br>");
counter++;
document.write(number+" x "+counter+" = "+number*counter+"<br>");
counter++;
document.write(number+" x "+counter+" = "+number*counter+"<br>");
counter++;
document.write(number+" x "+counter+" = "+number*counter+"<br>");
counter++;
document.write(number+" x "+counter+" = "+number*counter+"<br>");
counter++;
document.write(number+" x "+counter+" = "+number*counter+"<br>");
counter++;
document.write(number+" x "+counter+" = "+number*counter+"<br>");
counter++;
document.write(number+" x "+counter+" = "+number*counter+"<br>");
}
else
{
number = 5;
document.write(number+" x "+counter+" = "+number*counter+"<br>");
counter++;
document.write(number+" x "+counter+" = "+number*counter+"<br>");
counter++;
document.write(number+" x "+counter+" = "+number*counter+"<br>");
counter++;
document.write(number+" x "+counter+" = "+number*counter+"<br>");
counter++;
document.write(number+" x "+counter+" = "+number*counter+"<br>");
counter++;
document.write(number+" x "+counter+" = "+number*counter+"<br>");
counter++;
document.write(number+" x "+counter+" = "+number*counter+"<br>");
counter++;
document.write(number+" x "+counter+" = "+number*counter+"<br>");
counter++;
document.write(number+" x "+counter+" = "+number*counter+"<br>");
counter++;
document.write(number+" x "+counter+" = "+number*counter+"<br>");
}
//
//6
var urdu = 48;
var english = 54;
var math = 54;
var obtainedTotal = urdu + english + math;
 var total = 300;
 var percentage = obtainedTotal*100/total;
 document.write("<table>");
 document.write("<tr>");
 document.write("<th>Subject</th>");
 document.write("<th>Total Marks</th>");
 document.write("<th>Obtained Marks</th>");
 document.write("<th>Percentage</th>");
 document.write("</tr>");
 document.write("<tr>");
document.write("<td>English</td>"); 
document.write("<td>100</td>"); 
document.write("<td>"+english+"</td>"); 
 document.write("<td>"+(english*100)/100+"%"+"</td>"); 
 document.write("</tr>");
 document.write("<tr>");
document.write("<td>Math</td>"); 
document.write("<td>100</td>"); 
document.write("<td>"+math+"</td>"); 
 document.write("<td>"+(math*100)/100+"%"+"</td>"); 
 document.write("</tr>");
 document.write("<tr>");
document.write("<td>Urdu</td>"); 
document.write("<td>100</td>"); 
document.write("<td>"+urdu+"</td>"); 
 document.write("<td>"+(urdu*100)/100+"%"+"</td>"); 
 document.write("</tr>");
document.write("<tr>");
document.write("<td></td>");
document.write("<td><b>"+total+"</b></td>");
document.write("<td><b>"+obtainedTotal+"</b></td>");
document.write("<td><b>"+percentage+"%"+"</b></td>");
document.write("</tr>");
 document.write("</table>");
//
//end
//chapter9-11 start
//1
var city = prompt("Enter a city name");
if(city == "karachi" || city == "KARACHI" || city == "Karachi")
{
document.write("<h1>welcome to a city of lights</h1>");
}
else
{
document.write("<h1>welcome to city</h1>");
}
//
//2
var gender = prompt("Enter your gender");
if(gender == "MALE" || gender == "male" || gender == "Male")
{
document.write("<h1>Good Morning Sir.</h1>");
}
else if(gender == "FEMALE" || gender == "female" || gender == "Female")
{
document.write("<h1>Good Morning Ma’am.</h1>");
}
else
{
document.write("<h1>i don't know what to say to that.</h1>");
}
//
//3
var signal = prompt("Enter a traffic signal color name");
var message;
if(signal == "red" || signal == "Red" || signal == "RED")
{
message = "Must Stop";
}
else if(signal == "yellow" || signal == "Yellow" || signal == "YELLOW")
{
message = "ready to move";
}
else if(signal == "green" || signal == "Green" || signal == "GREEN")
{
message = "ready to move";
}
else
{
message = "unknown";
}
document.write("<table>");
document.write("<tr><th>Signal color</th><th>Message</th></tr>");
document.write("<tr>");
document.write("<td><b>"+signal+"</b></td>");
document.write("<td><b>"+message+"</b></td>");
document.write("</tr>");
document.write("</table>");
//
//4
var fuel = prompt("Enter fuel quantity");
fuel = parseFloat(fuel);
if(fuel < 0.25)
{
document.write("<h1>Please refill the fuel in your car</h1>");
}
else
{
document.write("<h1>you car has enough fuel</h1>");
}
//
//5
var a = 4;
if(++a === 5)
{
alert("given condition for variable a is true");
}
var b = 82;
if(b++ === 83)
{
alert("given condition for variable b is true");
}
var c = 12;
if(c++ === 13)
{
alert("condition 1 is true");
}
if(c === 13)
{
alert("condition 2 is true");
}
if(++c < 14)
{
alert("condition 3 is true");
}
if(c === 14)
{
alert("condition 4 is true");
}
var materialCost = 20000;
var laborCost = 2000;
var totalCost = materialCost + laborCost;
if(totalCost === laborCost + materialCost)
{
alert("The cost equals");
}
if(true)
{
alert("True");
}
if(false)
{
alert("False");
}
if("cat" < "cat")
{
alert("cat is smaller than cat");
}
//
//6
var  subject1 = prompt("Enter first subject obatined marks");
var  subject2 = prompt("Enter second subject obatined marks");
var  subject3 = prompt("Enter third subject obatined marks");
if(subject1 <= 100 && subject2 <= 100 && subject3 <= 100)
{
var totalMarks = 300;
var obtainedMarks = subject1 + subject2 + subject3;
var percentage = (obtainedMarks * 100) / totalMarks;
var grade;
var remarks;
if(percentage >= 80)
{
grade = "A1";
remarks = "Excellent";
} 
else if(percentage >= 70)
{
grade = "A";
remarks = "Good";
}
else if(percentage >= 60)
{
grade = "B";
remarks = "You need to improve";
}
else
{
grade = "Fail";
remarks = "Sorry";
}
document.write("<h1>Marks Sheet</h1><br>");
document.write("Total marks : "+totalMarks+"<br>");
document.write("Marks Obtained : "+obtainedMarks+"<br>");
document.write("Percentage : "+percentage+"%"+"<br>");
document.write("Grade : "+grade+"<br>");
document.write("Remarks : "+remarks+"<br>");
}
else
{
document.write("<h1>Enter valid subject marks</h1>");
}
//
//7
var secretNumber = 5;
var guess = prompt("Lets play a guess game \n guess a number from 1 to 10 and enter in the field below.");
if(guess)
{
if(guess >= 1 && guess <= 10)
{
if(guess == secretNumber)
{
document.write("<h1>“Bingo! Correct answer“.</h1>");
}
else if(++guess == secretNumber)
{
document.write("<h1>“Close enough to the correct answer”.</h1>");
}
else
{
document.write("<h1>Sorry you lose.</h1>");
}
}
else
{
document.write("<h1>Only numbers are allowed to enter and it should be from 1 to 10.</h1>");
}
}
else
{
document.write("<h2>Sorry you did'nt enter a number in the field ,try again and next time enter a number.</h2>");
}
//
//8
var Anumber = 12;
if(Anumber % 3 == 0)
{
document.write("<h2>The number you have stored in the variable is divisible by 3</h2>");
}
else
{
document.write("<h2>The number you have stored in the variable is not divisible by 3</h2>");
}
//
//9
var evenOrodd = parseInt(prompt("Enter a number"));
if(evenOrodd)
{
if(typeof(evenOrodd == "number"))
{
if(evenOrodd%2 == 0)
{
document.write("<h1>"+evenOrodd+" is an even number"+"<h1>");
}
else
{
document.write("<h1>"+evenOrodd+" is an odd number"+"<h1>");
}
}
else
{
document.write("<h1>You can only enter a number</h1>");
}
}
else
{
document.write("<h1>Please enter a number in the field</h1>");
}
//
//10
var temp = prompt("Enter weather temperature");
if(temp)
{
temp = parseInt(temp);
if(temp > 40)
{
document.write("<h1>It is to hot outside</h1>");
}
else if(temp > 30)
{
document.write("<h1>The weather today is normal</h1>");
}
else if(temp > 20)
{
document.write("<h1>Today's weather is cool</h1>");
}
else if(temp > 10)
{
document.write("<h1>OMG! Today's weather is so cool.</h1>");
}
}
else
{
document.write("<h1>Oh please enter something in the field</h1>");
}
//
//11 //please read with love like i did.
var number1,operator,number2;
number1 = prompt("Enter first numeric value");
number1 = parseInt(number1);
if(number1)
{
if(typeof(number1) == "number")
{
operator = prompt("Enter an arithmetic operator");
if(operator)
{
if(operator == "+" || operator == "-" || operator == "*" || operator == "/" || operator == "%")
{
number2 = prompt("Enter second numeric value");
number2 = parseInt(number2);
if(number2)
{
if(typeof(number2) == "number")
{
if(operator == "+")
{
document.write("<h1>"+number1+" "+"+"+" "+number2+" "+"="+" "+number1+number2+"</h1>");
}
else if(operator == "-")
{
document.write("<h1>"+number1+" "+"-"+" "+number2+" "+"="+" "+number1-number2+"</h1>");
}
else if(operator == "*")
{
document.write("<h1>"+number1+" "+"x"+" "+number2+" "+"="+" "+number1*number2+"</h1>");
}
else if(operator == "/")
{
document.write("<h1>"+number1+" "+"/"+" "+number2+" "+"="+" "+number1/number2+"</h1>");
}
else if(operator == "%")
{
document.write("<h1>"+number1+" reminder by "+number2+" is equal to "+number1%number2+"</h1>");
}
}
else
{
document.write("<h1>You can only enter a number in the first numeric value field</h1>");
}
}
else
{
document.write("<h1>Please enter a number in the second numeric value</h1>");
}
}
//
else
{
document.write("<h1>You can only enter an arithmetic character in the operator field</h1>");
}
}
else
{
document.write("<h1>Please enter an arithmetic character in the operator field</h1>");
}
}
else
{
document.write("<h1>You can only enter a number in the first numeric value field</h1>");
}
}
else
{
document.write("<h1>Please enter a number in the first numeric value</h1>");
}
//
//end
//chapter 12-13
//1
var numSw;
var aN = prompt('Enter a number or an alphabet');
if(aN)
{
if(aN.length < 2 && (!parseInt(aN)))
{
if(aN == '!' || aN == '@' || aN == '#' || aN == '$' || aN == '%' || aN == '^' || aN == '&' || aN == '*' || aN == '(' || aN == ')' || aN == '-' || aN == '_' || aN == '+' || aN == '=' || aN == '{' || aN == '}' || aN == '[' || aN == ']' || aN == '"\"' || aN == ';' || aN == ':' || aN == '"' || aN == "'" || aN == '<' || aN == ',' || aN == '>' || aN == '.' || aN == '/' || aN == '?' || aN == ' ' || aN == '~' || aN == '`')
{
if(aN == ' ')
{
document.write("<h1>"+"space is not an uppercase or lowercase letter beacuse it's not an alphabet");
}
else
{
document.write("<h1>"+aN+" "+"is not an uppercase or lowercase letter beacuse it's not an alphabet");
}
}
else if(aN == 'A' || aN == 'B' || aN == 'C' || aN == 'D' || aN == 'E' || aN == 'F' || aN == 'G' || aN == 'H' || aN == 'I' || aN == 'J' || aN == 'K' || aN == 'L' || aN == 'M' || aN == 'N' || aN == 'O' || aN == 'P' || aN == 'Q' || aN == 'R' || aN == 'S' || aN == 'T' || aN == 'U' || aN == 'V' || aN == 'W' || aN == 'X' || aN == 'Y' || aN == 'Z')
{
document.write("<h1>"+aN+" "+"is an uppercase letter"+"</h1>");
}
else if(aN == 'a' || aN == 'b' || aN == 'c' || aN == 'd' || aN == 'e' || aN == 'f' || aN == 'g' || aN == 'h' || aN == 'i' || aN == 'j' || aN == 'k' || aN == 'l' || aN == 'm' || aN == 'n' || aN == 'o' || aN == 'p' || aN == 'q' || aN == 'r' || aN == 's' || aN == 't' || aN == 'u' || aN == 'v' || aN == 'w' || aN == 'x' || aN == 'y' || aN == 'z')
{
document.write("<h1>"+aN+" "+"is a lowercase letter"+"</h1>");
}
}
else if(parseInt(aN))
{
document.write("<h1>"+aN+" "+"is a number"+"</h1>");
}
else
{
document.write("<h1>You can only enter one character in the field</h1>");
}
}
else
{
document.write("<h1>Please enter a number or alphabet in the field</h1>");
}
//
//2
var a = 8,b = 5;
if(a > b)
{
document.write("<h1>"+"a is equal to"+" "+a+" "+"and a"+" "+"is greater than b"+"</h1>");
}
else if(b > a)
{
document.write("<h1>"+"b is equal to"+" "+b+" "+" and b"+" "+"is greater than a"+"</h1>");
}
else if(a == b)
{
document.write("<h1>a is equal to b</h1>");
}
//
//3
var a = prompt("Enter a number");
if(a && a != " ")
{
if(parseInt(a))
{
if(a < 0)
{
document.write("<h1>"+a+" "+"is a negative number</h1>");
}
else if(a > 0)
{
document.write("<h1>"+a+" "+"is a positive number</h1>");
}
else
{
document.write("<h1>"+a+" "+"is a zero</h1>");
}
}
else
{
document.write("<h1>You can only enter a number.</h1>");
}
}
else
{
document.write("<h1>Please don't leave the field empty.</h1>");
}
//
//4
var vowel = prompt("Enter a character"+'\n'+"for example a,b,c etc");
if(vowel && vowel != " ")
{
if(vowel.length < 2)
{
if(vowel == 'a' || vowel == 'e' || vowel == 'i' || vowel == 'o' || vowel == 'u') 
{
document.write("<h1>"+vowel+" "+"is a vowel"+"</h1>");
}
else
{
document.write("<h1>"+vowel+" "+"is not a vowel</h1>");
}
}
else
{
document.write("<h1>Please enter only one character.</h1>");
}
}
else
{
document.write("<h1>Please don't leave the field empty</h1>");
}
//
//5
var correctPass = "devilmaycry";
var pass = prompt("Enter your password.");
if(pass && pass != " ")
{
if(pass == correctPass)
{
document.write("<h1>Correct! The password you entered matches the original password.</h1>");
}
else
{
document.write("<h1>Incorrect Password.</h1>");
}
}
else
{
document.write("<h1>Please enter your password.</h1>");
}
//
//6
var hour = 19;
if(hour < 18)
{
document.write("<h1>Good day!</h1>");
}
else
{
document.write("<h1>Good evening!</h1>");
}
//
//7
var time = prompt("Enter time");
if(time && parseInt(time))
{
if(time >= 0000 && time < 1200) 
{
document.write("<h1>Good morning!</h1>");
}
else if(time >=1200 && time < 1700)
{
document.write("<h1>Good afternoon!</h1>");
}
else if(time >= 1700 && time < 2100)
{
document.write("<h1>Good evening!</h1>");
}
else if(time >= 2100 && time <= 2359)
{
document.write("<h1>Good night!</h1>");
}
}
else
{
document.write("<h1>Please enter time.</h1>");
}
//
//end
//chapter14-16 start
//1
var arr1 = [];
//
//2
var arr2 = new Array();
//
//3
var str = ["name","country","city"];
//
//4
var nums = [1,2,3,4,5];
//
//5
var bool = [true,false,true,false];
//
//6
var mixed = ["pakistan",1990,true];
//
//7
var edu = ["SSC","HSC","BCS","BS","BCOM","MS","M.Phil","PhD"];
document.write("<h2>Qualifications:</h2>");
document.write("1)"+" "+edu[0]+"<br>");
document.write("2)"+" "+edu[1]+"<br>");
document.write("3)"+" "+edu[2]+"<br>");
document.write("4)"+" "+edu[3]+"<br>");
document.write("5)"+" "+edu[4]+"<br>");
document.write("6)"+" "+edu[5]+"<br>");
document.write("7)"+" "+edu[6]+"<br>");
document.write("8)"+" "+edu[7]+"<br>");
//
//8
var student = ["zain","faizan","alex"];
var score = [320,230,480];
document.write("Score of"+" "+student[0]+" "+"is"+" "+score[0]+" "+" Percentage:"+" "+(score[0]*100)/500+"%"+"<br>");
document.write("Score of"+" "+student[1]+" "+"is"+" "+score[1]+" "+" Percentage:"+" "+(score[1]*100)/500+"%"+"<br>");
document.write("Score of"+" "+student[2]+" "+"is"+" "+score[2]+" "+" Percentage:"+" "+(score[2]*100)/500+"%"+"<br>");
//
//9
var color = ["blue","orange","green"];
document.write(color+"<br>");
color.unshift(prompt("what color do you want to add? enter a color name"));
document.write(color+"<br>");
color.push(prompt("what color do you want to add? enter a color name"));
document.write(color+"<br>");
color.unshift(prompt("what color do you want to add? enter a color name"));
color.unshift(prompt("what color do you want to add? enter a color name"));
document.write(color+"<br>");
color.shift();
document.write(color+"<br>");
color.pop();
document.write(color+"<br>");
var index1 = prompt("What position you want to add a color? \n enter position number");
color[index1] = prompt("Enter your color name");
var index2 = prompt("What position you want to delete color? \n enter position number");
color.pop(index2);
//
//10
var studentScores = [320,230,480,120];
document.write("Scores of Students : "+studentScores+"<br>");
studentScores.sort();
document.write("Ordered Scores of Students : "+studentScores+"<br>");
//
//11
var cities = ["karachi","Lahore","Islamanbad","Quetta","Peshawar"];
var selectedCities= [];
selectedCities[0] = cities[2];
selectedCities[1] = cities[3];
document.write("Cities list :"+"<br>"+cities+"<br><br>");
document.write("Selected cities list :"+"<br>"+selectedCities+"<br>");
//
//12
var arr = ["This","is","my","cat"];
document.write("Array : <br>"+arr+"<br><br>");
var text = arr.join();
document.write("String :<br>"+text+"<br>");
//
//13
var arr = ["keyboard","mouse","printer","monitor"];
document.write("<br>"+arr+"<br><br>");
arr.reverse();
document.write("Out : <br>"+arr[3]+"<br>");
document.write("Out : <br>"+arr[2]+"<br>");
document.write("Out : <br>"+arr[1]+"<br>");
document.write("Out : <br>"+arr[0]+"<br>");
//
//14
var arr = ["keyboard","mouse","printer","monitor"];
document.write("<br>"+arr+"<br><br>");
arr.reverse();
document.write("Out : <br>"+arr[0]+"<br>");
document.write("Out : <br>"+arr[1]+"<br>");
document.write("Out : <br>"+arr[2]+"<br>");
document.write("Out : <br>"+arr[3]+"<br>");
//
//15
var phone = ["Apple","Samsung","Motorola","Nokia","Sony","Haier"];
document.write("<br><select>");
document.write("<option>"+phone[0]+"</option>");
document.write("<option>"+phone[1]+"</option>");
document.write("<option>"+phone[2]+"</option>");
document.write("<option>"+phone[3]+"</option>");
document.write("<option>"+phone[4]+"</option>");
document.write("<option>"+phone[5]+"</option>");
document.write("</select>");
//
//end
//exercise 1 start
//comment can make code readable
//excercise code in the varible.js file