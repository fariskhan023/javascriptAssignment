//2
var a = "something";
var b = true;
var c = undefined;
var b = null;
//
//3
var v1,v2,v3,v4;
//
//4
var va = "abc";
var vb = 123;
var vc = 99.91;
var vd = false;
//
//5
var firstName;
var lastName;
var martialStatus;
var country;
var age;
//
//6
var firstname,lastname,martialstatus,country,age;
//
//7
var myAge,yourAge;
myAge = 25;
yourAge = 30;
console.log("I am "+myAge+" years old.");
console.log("You are "+yourAge+" years old.");
//end
//exercise 2
//1
var first_Name = "faris";
var last_name  = "khan";
var country = "pakistan";
var city = "hyderabad";
var age = 26;
var isMarried = false;
var year = 1995;
document.write(typeof(first_Name)+"<br>");
document.write(typeof(last_Name)+"<br>");
document.write(typeof(country)+"<br>");
document.write(typeof(city)+"<br>");
document.write(typeof(age)+"<br>");
document.write(typeof(isMarried)+"<br>");
document.write(typeof(year)+"<br>");
//
//2
document.write("10" == 10);
document.write("<br>");
//
//3
document.write("10" === 10);
document.write("<br>");
//
//4
//i
if(true == 1)
{
	document.write(true);
	document.write("<br>");
}
if(false == 0)
{
document.write(true);	
	document.write("<br>");
}
if(true != 0)
{
	document.write(true);
	document.write("<br>");
}
//
//ii
if(false == 1)
{
	document.write(true);
	document.write("<br>");
}
else
{
	document.write(false);
	document.write("<br>");	
}
if(false != 0)
{
	document.write(true);
	document.write("<br>");
}
else
{
	document.write(false);
	document.write("<br>");	
}
if(false)
{
	document.write(true);
	document.write("<br>");
}
else
{
	document.write(false);
	document.write("<br>");	
}
//
//5
console.log(4 > 3);
console.log(4 >= 3);
console.log(4 < 3);
console.log(4 <= 3);
console.log(4 == 4);
console.log(4 === 4);
console.log(4 != 4);
console.log(4 !== 4);
console.log(4 !=  '4');
console.log(4 == '4');
console.log(4 === '4');
//
//6
var base = prompt("enter base of the triangle");
var height = prompt("enter height of the triangle");
var Area  = 0.5 * base * height;
document.write(Area+"<br>");
//
//7
var side_a = prompt("enter side a of the triangle ");
var side_b = prompt("enter side b of the triangle ");
var side_c = prompt("enter side c of the triangle ");
var perimeter = a + b + c;
//
//8
var hours = 40;
var ratePerHour = 28;
var weeklyEarning = hours*ratePerHour;
document.write("weeklyEarning : "+weeklyEarning+"<br>");
//
//end 
//exercise 3 start
var age = prompt("Enter your age");
if(age && parseInt(age))
{
	if(age >= 18)
	{
		document.write("You are old enough to drive");
	}
	else if(age == 15)
	{
		document.write("You are left with 3 years to drive");
	}
	else
	{
		document.write("Wait beacuse you are not old enough to drive");
	}
}
else
{
	document.write("enter your age in numbers");
}
//2
var number;
number = prompt();
if(number && parseInt(number))
{
	if(number%2 == 0)
	{
		document.write(number+" "+"is an even number");
	}
	else
	{
		document.write(number+" "+"is an odd number");
	}
}
//
//3
let myAge = 250;
let yourAge = 25;
document.write("I am"+" "+myAge+yourAge+" "+"years older than you.");
//
//end